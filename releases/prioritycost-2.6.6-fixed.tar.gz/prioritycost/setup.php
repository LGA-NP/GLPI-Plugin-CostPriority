<?php

use GlpiPlugin\Prioritycost\Config;

define('PLUGIN_PRIORITYCOST_VERSION', '2.6.6');

function plugin_init_prioritycost()
{
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['prioritycost'] = true;
    $PLUGIN_HOOKS['item_update']['prioritycost'] = ['Ticket' => 'plugin_prioritycost_item_update'];

    Plugin::registerClass(Config::class, ['addtabon' => [Entity::class]]);
}

function plugin_version_prioritycost()
{
    return [
        'name'         => 'Priority Cost',
        'version'      => PLUGIN_PRIORITYCOST_VERSION,
        'author'       => 'NexPoint Services',
        'license'      => 'GPLv3+',
        'requirements' => ['glpi' => ['min' => '11.0.0']],
    ];
}

/**
 * Run every ';'-terminated statement of a plain SQL file through the query
 * builder connection. The install/uninstall files shipped with this plugin
 * are simple, single-statement files with no string literal containing a
 * semicolon, so this naive split is safe here.
 */
function plugin_prioritycost_run_sql_file(string $path): void
{
    global $DB;

    $sql = file_get_contents($path);
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $statement) {
        $DB->doQuery($statement);
    }
}

function plugin_prioritycost_install()
{
    global $DB;

    if (!$DB->tableExists('glpi_plugin_prioritycost_rules')) {
        plugin_prioritycost_run_sql_file(__DIR__ . '/install/sql/mysql/install.sql');
    }

    return true;
}

function plugin_prioritycost_uninstall()
{
    global $DB;

    if ($DB->tableExists('glpi_plugin_prioritycost_rules')) {
        plugin_prioritycost_run_sql_file(__DIR__ . '/install/sql/mysql/uninstall.sql');
    }

    // Note: TicketCost rows created by this plugin (name = "Priority Cost")
    // are legitimate cost records on real tickets and are deliberately left
    // in place; GLPI itself removes the glpi_plugins row on uninstall, so
    // this function must not touch it.

    return true;
}
