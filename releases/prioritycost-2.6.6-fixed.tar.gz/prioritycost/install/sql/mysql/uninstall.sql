DROP TABLE IF EXISTS glpi_plugin_prioritycost_rules;
