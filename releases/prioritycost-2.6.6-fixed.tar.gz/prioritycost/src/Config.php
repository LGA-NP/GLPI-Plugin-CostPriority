<?php

namespace GlpiPlugin\Prioritycost;

use CommonDBTM;
use CommonGLPI;
use Entity;
use Session;

class Config extends CommonDBTM
{
    public static function getTypeName($nb = 0): string
    {
        return __('Priority Cost', 'prioritycost');
    }

    public static function canView(): bool
    {
        return Session::haveRight('entity', READ);
    }

    public static function canUpdate(): bool
    {
        return Session::haveRight('entity', UPDATE);
    }

    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0): string
    {
        return ($item instanceof Entity) ? __('Priority Cost', 'prioritycost') : '';
    }

    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0): bool
    {
        include GLPI_ROOT . '/plugins/prioritycost/front/entity.tab.php';
        return true;
    }

    /**
     * Walk the entity up its ancestors and return the first configured rule found
     * (child entity rule wins, falls back to the nearest configured ancestor).
     */
    public static function getRuleForEntityAndPriority(int $entity_id, int $priority): ?array
    {
        global $DB;

        $entity = new Entity();
        $ancestors = iterator_to_array($entity->getAncestors($entity_id), false);
        array_unshift($ancestors, $entity_id);

        foreach ($ancestors as $eid) {
            $res = $DB->request([
                'FROM'  => 'glpi_plugin_prioritycost_rules',
                'WHERE' => ['entities_id' => $eid, 'priority' => $priority],
            ]);
            if ($res->count()) {
                return $res->current();
            }
        }

        return null;
    }

    /**
     * Fetch the 6 priority rows (rule or null) configured directly on one entity
     * (no ancestor walk - this is for the "edit this entity" screen).
     */
    public static function getRulesForEntity(int $entity_id): array
    {
        global $DB;

        $rows = [];
        for ($p = 1; $p <= 6; $p++) {
            $rule = $DB->request([
                'FROM'  => 'glpi_plugin_prioritycost_rules',
                'WHERE' => ['entities_id' => $entity_id, 'priority' => $p],
            ])->current();

            $rows[$p] = [
                'priority'    => $p,
                'cost'        => $rule['cost'] ?? null,
                'budgets_id'  => $rule['budgets_id'] ?? 0,
            ];
        }

        return $rows;
    }

    /**
     * Save the posted cost/budget rules for one entity.
     *
     * @param array<int,mixed> $costs   priority => cost value (string from POST)
     * @param array<int,mixed> $budgets priority => budgets_id value (string from POST)
     */
    public static function saveRulesForEntity(int $entity_id, array $costs, array $budgets): void
    {
        global $DB;

        for ($p = 1; $p <= 6; $p++) {
            // Only ever act on the fixed, whitelisted 1-6 priority range: values
            // supplied under other array keys in the POST body are ignored.
            $DB->delete('glpi_plugin_prioritycost_rules', [
                'entities_id' => $entity_id,
                'priority'    => $p,
            ]);

            $cost = $costs[$p] ?? '';
            if ($cost === '' || $cost === null) {
                continue;
            }

            if (!is_numeric($cost)) {
                continue;
            }

            $budgets_id = (int)($budgets[$p] ?? 0);

            $DB->insert('glpi_plugin_prioritycost_rules', [
                'entities_id' => $entity_id,
                'priority'    => $p,
                'cost'        => (float)$cost,
                'budgets_id'  => $budgets_id > 0 ? $budgets_id : null,
            ]);
        }
    }
}
