<?php

use GlpiPlugin\Prioritycost\Config;
use Glpi\Application\View\TemplateRenderer;

// This file is always included by Config::displayTabContentForItem(), which
// itself only runs after GLPI's core tab framework has already required
// includes.php / checked the "entity" READ right for the containing item.
// The entity-scope check below is what stops that generic right from being
// enough to read another entity's configured costs.
Session::checkRight('entity', READ);

$entity_id = (int)($_GET['id'] ?? 0);

if (!Session::haveAccessToEntity($entity_id)) {
    Html::displayRightError();
}

$rows = Config::getRulesForEntity($entity_id);

$budget_names = [];
if (!empty($rows)) {
    global $DB;
    $ids = array_filter(array_column($rows, 'budgets_id'));
    if (!empty($ids)) {
        foreach ($DB->request(['FROM' => 'glpi_budgets', 'WHERE' => ['id' => $ids]]) as $budget) {
            $budget_names[$budget['id']] = $budget['name'];
        }
    }
}

TemplateRenderer::getInstance()->display('@prioritycost/entity_tab.html.twig', [
    'entity_id'     => $entity_id,
    'rules'         => $rows,
    'budget_names'  => $budget_names,
    'config_url'    => Plugin::getWebDir('prioritycost') . '/front/config.entity.php?entities_id=' . $entity_id,
]);
