<?php

use GlpiPlugin\Prioritycost\Config;
use Glpi\Application\View\TemplateRenderer;

include('../../../inc/includes.php');

Session::checkRight('entity', UPDATE);

$entity_id = (int)($_GET['entities_id'] ?? 0);

// Session::checkRight() only confirms the user holds the "entity" right
// *somewhere*; it does not confirm they may act on this specific entity.
// Without this check a user administering entity A could pass another
// entity's ID and read/write its rules (IDOR / horizontal privilege escalation).
if (!Session::haveAccessToEntity($entity_id)) {
    Html::displayRightError();
}

if (isset($_POST['save'])) {
    $costs   = is_array($_POST['cost'] ?? null) ? $_POST['cost'] : [];
    $budgets = is_array($_POST['budget'] ?? null) ? $_POST['budget'] : [];

    Config::saveRulesForEntity($entity_id, $costs, $budgets);

    Html::redirect($_SERVER['REQUEST_URI']);
}

Html::header(__('Priority Cost configuration', 'prioritycost'), '', 'admin', 'entity');

$rules = Config::getRulesForEntity($entity_id);

// Dropdown::show() echoes directly rather than returning a string, so each
// budget selector is rendered here and passed to the template as a raw HTML
// fragment (there is no user-controlled data in it: only entity_id and the
// already-numeric budgets_id are used to build the widget).
foreach ($rules as $p => $rule) {
    ob_start();
    Dropdown::show('Budget', [
        'name'   => "budget[$p]",
        'entity' => $entity_id,
        'value'  => $rule['budgets_id'],
    ]);
    $rules[$p]['budget_dropdown'] = ob_get_clean();
}

TemplateRenderer::getInstance()->display('@prioritycost/config_entity.html.twig', [
    'entity_id' => $entity_id,
    'rules'     => $rules,
    'csrf_token' => Session::getNewCSRFToken(),
]);

Html::footer();
