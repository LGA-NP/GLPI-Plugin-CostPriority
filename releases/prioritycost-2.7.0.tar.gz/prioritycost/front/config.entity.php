<?php

use GlpiPlugin\Prioritycost\Config;

include('../../../inc/includes.php');

Session::checkRight('entity', UPDATE);

$entity_id = (int)($_POST['entities_id'] ?? $_GET['entities_id'] ?? 0);

// Session::checkRight() only confirms the user holds the "entity" right
// *somewhere*; it does not confirm they may act on this specific entity.
// Without this check a user administering entity A could pass another
// entity's ID and overwrite its rules (IDOR / horizontal privilege escalation).
if (!Session::haveAccessToEntity($entity_id)) {
    Html::displayRightError();
}

if (isset($_POST['save'])) {
    $costs = is_array($_POST['cost'] ?? null) ? $_POST['cost'] : [];
    $budgets_id = (int)($_POST['budgets_id'] ?? 0);

    Config::saveRulesForEntity($entity_id, $costs);
    Config::saveBudgetForEntity($entity_id, $budgets_id > 0 ? $budgets_id : null);
}

// The form now lives directly in the entity's "Priority Cost" tab (see
// front/entity.tab.php); this endpoint only ever processes the save and
// sends the user straight back to that tab - there is no separate
// "configure" screen to click through to anymore.
Html::redirect(Entity::getFormURLWithID($entity_id) . '&forcetab=' . urlencode(Config::class) . '$1');
