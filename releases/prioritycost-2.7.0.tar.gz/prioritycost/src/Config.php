<?php

namespace GlpiPlugin\Prioritycost;

use CommonDBTM;
use CommonGLPI;
use Entity;
use Session;

class Config extends CommonDBTM
{
    public static function getTypeName($nb = 0): string
    {
        return __('Priority Cost', 'prioritycost');
    }

    public static function canView(): bool
    {
        return Session::haveRight('entity', READ);
    }

    public static function canUpdate(): bool
    {
        return Session::haveRight('entity', UPDATE);
    }

    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0): string
    {
        if (!($item instanceof Entity)) {
            return '';
        }

        // 4th arg is a Font Awesome icon class shown before the tab label.
        return self::createTabEntry(__('Priority Cost', 'prioritycost'), 0, $item::getType(), 'fas fa-coins');
    }

    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0): bool
    {
        include GLPI_ROOT . '/plugins/prioritycost/front/entity.tab.php';
        return true;
    }

    /**
     * Walk the entity up its ancestors and return the first configured cost
     * rule found (child entity rule wins, falls back to the nearest
     * configured ancestor), with the budget configured on that SAME entity
     * merged in under 'budgets_id' (the budget follows the rule that matched,
     * not necessarily the leaf entity's own budget).
     */
    public static function getRuleForEntityAndPriority(int $entity_id, int $priority): ?array
    {
        global $DB;

        $entity = new Entity();
        $ancestors = iterator_to_array($entity->getAncestors($entity_id), false);
        array_unshift($ancestors, $entity_id);

        foreach ($ancestors as $eid) {
            $res = $DB->request([
                'FROM'  => 'glpi_plugin_prioritycost_rules',
                'WHERE' => ['entities_id' => $eid, 'priority' => $priority],
            ]);
            if ($res->count()) {
                $rule = $res->current();
                $rule['budgets_id'] = self::getBudgetForEntity((int)$eid);
                return $rule;
            }
        }

        return null;
    }

    /**
     * Fetch the 6 priority rows (cost or null) configured directly on one
     * entity (no ancestor walk - this is for the entity's own edit screen).
     */
    public static function getRulesForEntity(int $entity_id): array
    {
        global $DB;

        $rows = [];
        for ($p = 1; $p <= 6; $p++) {
            $rule = $DB->request([
                'FROM'  => 'glpi_plugin_prioritycost_rules',
                'WHERE' => ['entities_id' => $entity_id, 'priority' => $p],
            ])->current();

            $rows[$p] = [
                'priority' => $p,
                'cost'     => $rule['cost'] ?? null,
            ];
        }

        return $rows;
    }

    /**
     * The single budget configured for this entity (one per entity, shared
     * by every priority level), or null if none is set.
     */
    public static function getBudgetForEntity(int $entity_id): ?int
    {
        global $DB;

        $row = $DB->request([
            'FROM'  => 'glpi_plugin_prioritycost_configs',
            'WHERE' => ['entities_id' => $entity_id],
        ])->current();

        return !empty($row['budgets_id']) ? (int)$row['budgets_id'] : null;
    }

    /**
     * Save the posted per-priority costs for one entity.
     *
     * @param array<int,mixed> $costs priority => cost value (raw string from POST)
     */
    public static function saveRulesForEntity(int $entity_id, array $costs): void
    {
        global $DB;

        for ($p = 1; $p <= 6; $p++) {
            // Only ever act on the fixed, whitelisted 1-6 priority range: values
            // supplied under other array keys in the POST body are ignored.
            $DB->delete('glpi_plugin_prioritycost_rules', [
                'entities_id' => $entity_id,
                'priority'    => $p,
            ]);

            $cost = $costs[$p] ?? '';
            if ($cost === '' || $cost === null || !is_numeric($cost)) {
                continue;
            }

            $DB->insert('glpi_plugin_prioritycost_rules', [
                'entities_id' => $entity_id,
                'priority'    => $p,
                'cost'        => (float)$cost,
            ]);
        }
    }

    /**
     * Save (or clear) the single budget for one entity.
     */
    public static function saveBudgetForEntity(int $entity_id, ?int $budgets_id): void
    {
        global $DB;

        $DB->delete('glpi_plugin_prioritycost_configs', ['entities_id' => $entity_id]);

        if (!empty($budgets_id)) {
            $DB->insert('glpi_plugin_prioritycost_configs', [
                'entities_id' => $entity_id,
                'budgets_id'  => $budgets_id,
            ]);
        }
    }
}
